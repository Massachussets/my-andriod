package com.my.prayers.scedule;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import com.google.android.material.appbar.AppBarLayout;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.ActionBarDrawerToggle;
import android.widget.LinearLayout;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;
import org.json.*;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.ImageView;
import android.content.Intent;
import android.net.Uri;
import java.util.Calendar;
import java.text.SimpleDateFormat;
import android.app.Activity;
import android.content.SharedPreferences;
import android.view.View;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.DialogFragment;


public class MainActivity extends  AppCompatActivity  { 
	
	
	private Toolbar _toolbar;
	private AppBarLayout _app_bar;
	private CoordinatorLayout _coordinator;
	private DrawerLayout _drawer;
	private String fontName = "";
	private String typeace = "";
	private String d = "";
	
	private ScrollView vscroll1;
	private LinearLayout linear1;
	private LinearLayout linear2;
	private LinearLayout linear12;
	private LinearLayout linear13;
	private TextView no_internet;
	private LinearLayout linear14;
	private LinearLayout linear3;
	private LinearLayout linear4;
	private LinearLayout linear5;
	private LinearLayout linear6;
	private LinearLayout linear7;
	private LinearLayout linear8;
	private ImageView imageview1;
	private TextView textview1;
	private TextView sunrise;
	private ImageView imageview2;
	private TextView textview3;
	private TextView sunset;
	private ImageView imageview3;
	private TextView textview6;
	private DigitalClock digitalclock1;
	private LinearLayout linear9;
	private LinearLayout linear10;
	private TextView textview7;
	private TextView shari;
	private TextView textview9;
	private TextView ifter;
	private TextView textview13;
	private TextView date;
	private TextView hijri;
	private ImageView imageview4;
	private TextView textview16;
	private TextView location;
	private LinearLayout linear15;
	private LinearLayout linear16;
	private LinearLayout linear17;
	private LinearLayout linear18;
	private LinearLayout linear19;
	private LinearLayout linear20;
	private TextView textview19;
	private ImageView imageview5;
	private TextView fajr;
	private TextView textview20;
	private ImageView imageview6;
	private TextView duhur;
	private TextView textview21;
	private ImageView imageview7;
	private TextView asr;
	private TextView textview22;
	private ImageView imageview8;
	private TextView maghrib;
	private TextView textview23;
	private ImageView imageview9;
	private TextView isha;
	private TextView textview24;
	private ImageView imageview10;
	private TextView midnight;
	private ScrollView _drawer_vscroll1;
	private LinearLayout _drawer_LinearLayout;
	private LinearLayout _drawer_background;
	private LinearLayout _drawer_linear1;
	private LinearLayout _drawer_linear2;
	private LinearLayout _drawer_linear3;
	private LinearLayout _drawer_linear4;
	private LinearLayout _drawer_linear5;
	private LinearLayout _drawer_linear;
	private TextView _drawer_textview7;
	private LinearLayout _drawer_linear6;
	private LinearLayout _drawer_linear7;
	private LinearLayout _drawer_linear8;
	private LinearLayout _drawer_linear9;
	private LinearLayout _drawer_linear10;
	private LinearLayout _drawer_linear11;
	private TextView _drawer_textview1;
	private ImageView _drawer_imageview1;
	private TextView _drawer_textview2;
	private ImageView _drawer_imageview2;
	private TextView _drawer_textview3;
	private ImageView _drawer_imageview3;
	private TextView _drawer_textview4;
	private ImageView _drawer_imageview5;
	private TextView _drawer_textview6;
	private ImageView _drawer_imageview4;
	private TextView _drawer_textview5;
	private ImageView _drawer_imageview6;
	private TextView _drawer_textview8;
	private ImageView _drawer_imageview7;
	private TextView _drawer_textview9;
	private ImageView _drawer_imageview9;
	private TextView _drawer_textview12;
	private ImageView _drawer_imageview8;
	private TextView _drawer_textview10;
	private ImageView _drawer_imageview11;
	private TextView _drawer_textview13;
	private ImageView _drawer_imageview10;
	private TextView _drawer_textview11;
	
	private RequestNetwork Rr;
	private RequestNetwork.RequestListener _Rr_request_listener;
	private Intent intent = new Intent();
	private Calendar cl = Calendar.getInstance();
	private SharedPreferences data;
	private SharedPreferences RR;
	private RequestNetwork id;
	private RequestNetwork.RequestListener _id_request_listener;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		_app_bar = (AppBarLayout) findViewById(R.id._app_bar);
		_coordinator = (CoordinatorLayout) findViewById(R.id._coordinator);
		_toolbar = (Toolbar) findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		_drawer = (DrawerLayout) findViewById(R.id._drawer);
		ActionBarDrawerToggle _toggle = new ActionBarDrawerToggle(MainActivity.this, _drawer, _toolbar, R.string.app_name, R.string.app_name);
		_drawer.addDrawerListener(_toggle);
		_toggle.syncState();
		
		LinearLayout _nav_view = (LinearLayout) findViewById(R.id._nav_view);
		
		vscroll1 = (ScrollView) findViewById(R.id.vscroll1);
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		linear12 = (LinearLayout) findViewById(R.id.linear12);
		linear13 = (LinearLayout) findViewById(R.id.linear13);
		no_internet = (TextView) findViewById(R.id.no_internet);
		linear14 = (LinearLayout) findViewById(R.id.linear14);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		linear5 = (LinearLayout) findViewById(R.id.linear5);
		linear6 = (LinearLayout) findViewById(R.id.linear6);
		linear7 = (LinearLayout) findViewById(R.id.linear7);
		linear8 = (LinearLayout) findViewById(R.id.linear8);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		textview1 = (TextView) findViewById(R.id.textview1);
		sunrise = (TextView) findViewById(R.id.sunrise);
		imageview2 = (ImageView) findViewById(R.id.imageview2);
		textview3 = (TextView) findViewById(R.id.textview3);
		sunset = (TextView) findViewById(R.id.sunset);
		imageview3 = (ImageView) findViewById(R.id.imageview3);
		textview6 = (TextView) findViewById(R.id.textview6);
		digitalclock1 = (DigitalClock) findViewById(R.id.digitalclock1);
		linear9 = (LinearLayout) findViewById(R.id.linear9);
		linear10 = (LinearLayout) findViewById(R.id.linear10);
		textview7 = (TextView) findViewById(R.id.textview7);
		shari = (TextView) findViewById(R.id.shari);
		textview9 = (TextView) findViewById(R.id.textview9);
		ifter = (TextView) findViewById(R.id.ifter);
		textview13 = (TextView) findViewById(R.id.textview13);
		date = (TextView) findViewById(R.id.date);
		hijri = (TextView) findViewById(R.id.hijri);
		imageview4 = (ImageView) findViewById(R.id.imageview4);
		textview16 = (TextView) findViewById(R.id.textview16);
		location = (TextView) findViewById(R.id.location);
		linear15 = (LinearLayout) findViewById(R.id.linear15);
		linear16 = (LinearLayout) findViewById(R.id.linear16);
		linear17 = (LinearLayout) findViewById(R.id.linear17);
		linear18 = (LinearLayout) findViewById(R.id.linear18);
		linear19 = (LinearLayout) findViewById(R.id.linear19);
		linear20 = (LinearLayout) findViewById(R.id.linear20);
		textview19 = (TextView) findViewById(R.id.textview19);
		imageview5 = (ImageView) findViewById(R.id.imageview5);
		fajr = (TextView) findViewById(R.id.fajr);
		textview20 = (TextView) findViewById(R.id.textview20);
		imageview6 = (ImageView) findViewById(R.id.imageview6);
		duhur = (TextView) findViewById(R.id.duhur);
		textview21 = (TextView) findViewById(R.id.textview21);
		imageview7 = (ImageView) findViewById(R.id.imageview7);
		asr = (TextView) findViewById(R.id.asr);
		textview22 = (TextView) findViewById(R.id.textview22);
		imageview8 = (ImageView) findViewById(R.id.imageview8);
		maghrib = (TextView) findViewById(R.id.maghrib);
		textview23 = (TextView) findViewById(R.id.textview23);
		imageview9 = (ImageView) findViewById(R.id.imageview9);
		isha = (TextView) findViewById(R.id.isha);
		textview24 = (TextView) findViewById(R.id.textview24);
		imageview10 = (ImageView) findViewById(R.id.imageview10);
		midnight = (TextView) findViewById(R.id.midnight);
		_drawer_vscroll1 = (ScrollView) _nav_view.findViewById(R.id.vscroll1);
		_drawer_LinearLayout = (LinearLayout) _nav_view.findViewById(R.id.LinearLayout);
		_drawer_background = (LinearLayout) _nav_view.findViewById(R.id.background);
		_drawer_linear1 = (LinearLayout) _nav_view.findViewById(R.id.linear1);
		_drawer_linear2 = (LinearLayout) _nav_view.findViewById(R.id.linear2);
		_drawer_linear3 = (LinearLayout) _nav_view.findViewById(R.id.linear3);
		_drawer_linear4 = (LinearLayout) _nav_view.findViewById(R.id.linear4);
		_drawer_linear5 = (LinearLayout) _nav_view.findViewById(R.id.linear5);
		_drawer_linear = (LinearLayout) _nav_view.findViewById(R.id.linear);
		_drawer_textview7 = (TextView) _nav_view.findViewById(R.id.textview7);
		_drawer_linear6 = (LinearLayout) _nav_view.findViewById(R.id.linear6);
		_drawer_linear7 = (LinearLayout) _nav_view.findViewById(R.id.linear7);
		_drawer_linear8 = (LinearLayout) _nav_view.findViewById(R.id.linear8);
		_drawer_linear9 = (LinearLayout) _nav_view.findViewById(R.id.linear9);
		_drawer_linear10 = (LinearLayout) _nav_view.findViewById(R.id.linear10);
		_drawer_linear11 = (LinearLayout) _nav_view.findViewById(R.id.linear11);
		_drawer_textview1 = (TextView) _nav_view.findViewById(R.id.textview1);
		_drawer_imageview1 = (ImageView) _nav_view.findViewById(R.id.imageview1);
		_drawer_textview2 = (TextView) _nav_view.findViewById(R.id.textview2);
		_drawer_imageview2 = (ImageView) _nav_view.findViewById(R.id.imageview2);
		_drawer_textview3 = (TextView) _nav_view.findViewById(R.id.textview3);
		_drawer_imageview3 = (ImageView) _nav_view.findViewById(R.id.imageview3);
		_drawer_textview4 = (TextView) _nav_view.findViewById(R.id.textview4);
		_drawer_imageview5 = (ImageView) _nav_view.findViewById(R.id.imageview5);
		_drawer_textview6 = (TextView) _nav_view.findViewById(R.id.textview6);
		_drawer_imageview4 = (ImageView) _nav_view.findViewById(R.id.imageview4);
		_drawer_textview5 = (TextView) _nav_view.findViewById(R.id.textview5);
		_drawer_imageview6 = (ImageView) _nav_view.findViewById(R.id.imageview6);
		_drawer_textview8 = (TextView) _nav_view.findViewById(R.id.textview8);
		_drawer_imageview7 = (ImageView) _nav_view.findViewById(R.id.imageview7);
		_drawer_textview9 = (TextView) _nav_view.findViewById(R.id.textview9);
		_drawer_imageview9 = (ImageView) _nav_view.findViewById(R.id.imageview9);
		_drawer_textview12 = (TextView) _nav_view.findViewById(R.id.textview12);
		_drawer_imageview8 = (ImageView) _nav_view.findViewById(R.id.imageview8);
		_drawer_textview10 = (TextView) _nav_view.findViewById(R.id.textview10);
		_drawer_imageview11 = (ImageView) _nav_view.findViewById(R.id.imageview11);
		_drawer_textview13 = (TextView) _nav_view.findViewById(R.id.textview13);
		_drawer_imageview10 = (ImageView) _nav_view.findViewById(R.id.imageview10);
		_drawer_textview11 = (TextView) _nav_view.findViewById(R.id.textview11);
		Rr = new RequestNetwork(this);
		data = getSharedPreferences("data", Activity.MODE_PRIVATE);
		RR = getSharedPreferences("data", Activity.MODE_PRIVATE);
		id = new RequestNetwork(this);
		
		linear13.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent.setClass(getApplicationContext(), SettingsActivity.class);
				startActivity(intent);
			}
		});
		
		_Rr_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				d = _response;
				RR.edit().remove("R").commit();
				RR.edit().putString("R", _response).commit();
				shari.setText(d.substring((int)(d.indexOf("\"Imsak\":\"")), (int)(d.indexOf("\",\"Sunrise\":\""))).replace("\"Imsak\":\"", "").concat(" AM"));
				sunrise.setText(d.substring((int)(d.indexOf("\"Sunrise\":\"")), (int)(d.indexOf("\",\"Fajr\":\""))).replace("\"Sunrise\":\"", "").concat(" AM"));
				fajr.setText(d.substring((int)(d.indexOf("\"Fajr\":\"")), (int)(d.indexOf("\",\"Dhuhr\":\""))).replace("\"Fajr\":\"", "").concat(" AM"));
				duhur.setText(d.substring((int)(d.indexOf("\"Dhuhr\":\"")), (int)(d.indexOf("\",\"Asr\":\""))).replace("\"Dhuhr\":\"", "").concat(" PM"));
				asr.setText(d.substring((int)(d.indexOf("\"Asr\":\"")), (int)(d.indexOf("\",\"Sunset\":\""))).replace("\"Asr\":\"", "").concat(" PM"));
				sunset.setText(d.substring((int)(d.indexOf("\"Sunset\":\"")), (int)(d.indexOf("\",\"Maghrib\":\""))).replace("\"Sunset\":\"", "").concat(" PM"));
				maghrib.setText(d.substring((int)(d.indexOf("\"Maghrib\":\"")), (int)(d.indexOf("\",\"Isha\":\""))).replace("\"Maghrib\":\"", "").concat(" PM"));
				isha.setText(d.substring((int)(d.indexOf("\"Isha\":\"")), (int)(d.indexOf("\",\"Midnight\":\""))).replace("\"Isha\":\"", "").concat(" PM"));
				midnight.setText(d.substring((int)(d.indexOf("\"Midnight\":\"")), (int)(d.indexOf("\"},"))).replace("\"Midnight\":\"", "").concat(" AM"));
				ifter.setText(maghrib.getText().toString());
				date.setText(d.substring((int)(d.indexOf("\"gregorian\":\"")), (int)(d.indexOf("\",\"hijri\":\""))).replace("\"gregorian\":\"", ""));
				hijri.setText(d.substring((int)(d.indexOf("\"hijri\":\"")), (int)(d.indexOf("\"}}],"))).replace("\"hijri\":\"", ""));
				location.setText(d.substring((int)(d.indexOf("\"city\":\"")), (int)(d.indexOf("\",\"country\":\""))).replace("\"city\":\"", "").concat(",".concat(d.substring((int)(d.indexOf("\"country\":\"")), (int)(d.indexOf("\",\"country_code\":\""))).replace("\"country\":\"", ""))));
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_id_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				data.edit().putString("d", new SimpleDateFormat("yyyy-MM-dd").format(cl.getTime())).commit();
				Rr.startRequestNetwork(RequestNetworkController.GET, "https://api.pray.zone/v2/times/today.json?city=Tangail", "", _Rr_request_listener);
				no_internet.setVisibility(View.GONE);
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				no_internet.setVisibility(View.VISIBLE);
				SketchwareUtil.showMessage(getApplicationContext(), "Give the internet connection for the correct Prayers Scedule");
				_offline();
			}
		};
	}
	
	private void initializeLogic() {
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Override
	public void onBackPressed() {
		if (_drawer.isDrawerOpen(GravityCompat.START)) {
			_drawer.closeDrawer(GravityCompat.START);
		}
		else {
			super.onBackPressed();
		}
	}
	public void _ICC (final ImageView _img, final String _c1, final String _c2) {
		_img.setImageTintList(new android.content.res.ColorStateList(new int[][] {{-android.R.attr.state_pressed},{android.R.attr.state_pressed}},new int[]{Color.parseColor(_c1), Color.parseColor(_c2)}));
	}
	
	
	public void _GradientDrawable (final View _view, final double _radius, final double _stroke, final double _shadow, final String _color, final String _borderColor, final boolean _ripple, final boolean _clickAnim, final double _animDuration) {
		if (_ripple) {
			android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
			gd.setColor(Color.parseColor(_color));
			gd.setCornerRadius((int)_radius);
			gd.setStroke((int)_stroke,Color.parseColor(_borderColor));
			if (Build.VERSION.SDK_INT >= 21){
				_view.setElevation((int)_shadow);}
			android.content.res.ColorStateList clrb = new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{Color.parseColor("#9E9E9E")});
			android.graphics.drawable.RippleDrawable ripdrb = new android.graphics.drawable.RippleDrawable(clrb , gd, null);
			_view.setClickable(true);
			_view.setBackground(ripdrb);
		}
		else {
			android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
			gd.setColor(Color.parseColor(_color));
			gd.setCornerRadius((int)_radius);
			gd.setStroke((int)_stroke,Color.parseColor(_borderColor));
			_view.setBackground(gd);
			if (Build.VERSION.SDK_INT >= 21){
				_view.setElevation((int)_shadow);}
		}
		if (_clickAnim) {
			_view.setOnTouchListener(new View.OnTouchListener() {
				@Override
				public boolean onTouch(View v, MotionEvent event) {
					switch (event.getAction()){
						case MotionEvent.ACTION_DOWN:{
							ObjectAnimator scaleX = new ObjectAnimator();
							scaleX.setTarget(_view);
							scaleX.setPropertyName("scaleX");
							scaleX.setFloatValues(0.9f);
							scaleX.setDuration((int)_animDuration);
							scaleX.start();
							
							ObjectAnimator scaleY = new ObjectAnimator();
							scaleY.setTarget(_view);
							scaleY.setPropertyName("scaleY");
							scaleY.setFloatValues(0.9f);
							scaleY.setDuration((int)_animDuration);
							scaleY.start();
							break;
						}
						case MotionEvent.ACTION_UP:{
							
							ObjectAnimator scaleX = new ObjectAnimator();
							scaleX.setTarget(_view);
							scaleX.setPropertyName("scaleX");
							scaleX.setFloatValues((float)1);
							scaleX.setDuration((int)_animDuration);
							scaleX.start();
							
							ObjectAnimator scaleY = new ObjectAnimator();
							scaleY.setTarget(_view);
							scaleY.setPropertyName("scaleY");
							scaleY.setFloatValues((float)1);
							scaleY.setDuration((int)_animDuration);
							scaleY.start();
							
							break;
						}
					}
					return false;
				}
			});
		}
	}
	
	
	public void _changeActivityFont (final String _fontname) {
		fontName = "fonts/".concat(_fontname.concat(".ttf"));
		overrideFonts(this,getWindow().getDecorView()); 
	} 
	private void overrideFonts(final android.content.Context context, final View v) {
		
		try {
			Typeface 
			typeace = Typeface.createFromAsset(getAssets(), fontName);;
			if ((v instanceof ViewGroup)) {
				ViewGroup vg = (ViewGroup) v;
				for (int i = 0;
				i < vg.getChildCount();
				i++) {
					View child = vg.getChildAt(i);
					overrideFonts(context, child);
				}
			}
			else {
				if ((v instanceof TextView)) {
					((TextView) v).setTypeface(typeace);
				}
				else {
					if ((v instanceof EditText )) {
						((EditText) v).setTypeface(typeace);
					}
					else {
						if ((v instanceof Button)) {
							((Button) v).setTypeface(typeace);
						}
					}
				}
			}
		}
		catch(Exception e)
		
		{
			SketchwareUtil.showMessage(getApplicationContext(), "Error Loading Font");
		};
	}
	
	
	public void _offline () {
		try{
			d = RR.getString("R", "");
			shari.setText(d.substring((int)(d.indexOf("\"Imsak\":\"")), (int)(d.indexOf("\",\"Sunrise\":\""))).replace("\"Imsak\":\"", "").concat(" AM"));
			sunrise.setText(d.substring((int)(d.indexOf("\"Sunrise\":\"")), (int)(d.indexOf("\",\"Fajr\":\""))).replace("\"Sunrise\":\"", "").concat(" AM"));
			fajr.setText(d.substring((int)(d.indexOf("\"Fajr\":\"")), (int)(d.indexOf("\",\"Dhuhr\":\""))).replace("\"Fajr\":\"", "").concat(" AM"));
			duhur.setText(d.substring((int)(d.indexOf("\"Dhuhr\":\"")), (int)(d.indexOf("\",\"Asr\":\""))).replace("\"Dhuhr\":\"", "").concat(" PM"));
			asr.setText(d.substring((int)(d.indexOf("\"Asr\":\"")), (int)(d.indexOf("\",\"Sunset\":\""))).replace("\"Asr\":\"", "").concat(" PM"));
			sunset.setText(d.substring((int)(d.indexOf("\"Sunset\":\"")), (int)(d.indexOf("\",\"Maghrib\":\""))).replace("\"Sunset\":\"", "").concat(" PM"));
			maghrib.setText(d.substring((int)(d.indexOf("\"Maghrib\":\"")), (int)(d.indexOf("\",\"Isha\":\""))).replace("\"Maghrib\":\"", "").concat(" PM"));
			isha.setText(d.substring((int)(d.indexOf("\"Isha\":\"")), (int)(d.indexOf("\",\"Midnight\":\""))).replace("\"Isha\":\"", "").concat(" PM"));
			midnight.setText(d.substring((int)(d.indexOf("\"Midnight\":\"")), (int)(d.indexOf("\"},"))).replace("\"Midnight\":\"", "").concat(" AM"));
			ifter.setText(maghrib.getText().toString());
			date.setText(d.substring((int)(d.indexOf("\"gregorian\":\"")), (int)(d.indexOf("\",\"hijri\":\""))).replace("\"gregorian\":\"", ""));
			hijri.setText(d.substring((int)(d.indexOf("\"hijri\":\"")), (int)(d.indexOf("\"}}],"))).replace("\"hijri\":\"", ""));
			location.setText(d.substring((int)(d.indexOf("\"city\":\"")), (int)(d.indexOf("\",\"country\":\""))).replace("\"city\":\"", "").concat(",".concat(d.substring((int)(d.indexOf("\"country\":\"")), (int)(d.indexOf("\",\"country_code\":\""))).replace("\"country\":\"", ""))));
		} catch(Exception _e){ //do something if error occurs //To know error use _e.toString()
		}
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}